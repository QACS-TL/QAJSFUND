// worker.js
// Import parentPort
// parentPort allows the worker to receive messages from the main thread.
import { parentPort } from 'node:worker_threads';

// Create shared memory
// A SharedArrayBuffer of 4 bytes is created—enough for one Int32.
// We wrap it in an Int32Array called ia.
//
// Initially:
//     ia[0] === 0
//
// This value is what we will wait on and notify on.
const sab = new SharedArrayBuffer(4);
const ia = new Int32Array(sab);

// Wait for memory value to change from 0 → something else
// Define an async function
// This function performs the “sleep until main thread wakes me” behavior.
async function sleepUntilNotified() {
  // Log that the worker is going to sleep
  // This confirms the worker reached the waiting stage.  
  console.log("Worker: going to sleep...");

  // Read the current memory value
  // expected = ia[0], which is 0.
  // This means:
  //   “Sleep until the value at ia[0] is no longer 0.”
  const expected = Atomics.load(ia, 0);

  // Call Atomics.waitAsync()
  // - It returns an object, NOT a Promise.
  // - .value is the Promise representing the async sleep.
  // This means:
  //  -- “Pause here until notified.”
  // This sleep is non‑blocking — the worker thread can still receive messages while sleeping.
  const result = Atomics.waitAsync(ia, 0, expected);
  await result.value;   // IMPORTANT: .value is the Promise

  // When woken, this line runs
  // Main thread calls Atomics.notify(ia, 0, 1).
  // This resolves the Promise returned by waitAsync.
  // Log that the worker woke up

  console.log("Worker: woke up!");
  // Exit the worker thread
  // Calling process.exit(0) ensures the worker ends cleanly.
  // When the worker exits, the main thread process also ends, because there is nothing left keeping it alive.
  process.exit(0); // necessary or program will hang
}

// Start the sleep function immediately
sleepUntilNotified();

// When main thread says “wake”, we update memory and notify
// Listen for a message from main.js
// We use .once(), meaning:
// - The handler runs only once, then is removed.
// This is important because it avoids keeping the worker alive unnecessarily after it's woken.
parentPort.on("message", () => {
  // When the message arrives:
  // Atomics.store(ia, 0, 1) changes the memory value from 0 → 1.
  // This satisfies the “wake when ia[0] ≠ 0” condition.
  // Atomics.notify(ia, 0, 1) wakes one sleeping waiter.
  // In this case, the worker itself.
  // This causes the Promise in:
  //  wait Atomics.waitAsync(...).value
  // to resolve, and the worker resumes execution.
  Atomics.store(ia, 0, 1);
  Atomics.notify(ia, 0, 1);
});
// NOTE: you can omit the Atomics.store(ia, 0, 1); and the waiter will wake.
// BUT ⚠️
// If you skip the store, the memory still contains the old value (0) - notify:
// - Wakes up waiters sleeping on arr[index]
// - Does NOT modify arr[index]
// - Does NOT satisfy the “expected value changed” condition for Atomics.waitAsync() on its own
// If your code checks the value afterward (many real‑world patterns do), it will not reflect the state change.