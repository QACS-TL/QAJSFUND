//Uing Object Mapping
const day = 2;

const dayMapping = {
  1: "It's Sunday",
  2: "It's Monday",
  3: "It's Tuesday",
  4: "It's Wednesday",
  5: "It's Thursday",
  6: "It's Friday",
  default: "It's Saturday"
};

const result = dayMapping[day] || dayMapping.default;

console.log(result); // Output: "It's Monday"


//using switch
let sresult;
switch (day) {
 case 1:
   sresult = "It's Sunday";
 break;
 case 2:
   sresult = "It's Monday";
 break;
 case 3:
   sresult = "It's Tuesday";
 break;
 case 4:
   sresult = "It's Wednesday";
 break;
 case 5:
   sresult = "It's Thursday";
 break;
 case 6:
   sresult = "It's Friday";
 break;
 default:
   sresult = "It's Saturday";
}
console.log(sresult); // Output: "It's Monday"


const fruit = { type: 'apple', color: 'red', weight: 150 };

const message = match(fruit) {
    { type: 'apple', color: 'red' } => 'This is a red apple.',
    { type: 'apple', color: 'green' } => 'This is a green apple.',
        { type: 'banana' } => 'This is a banana.',
            _ => 'Unknown fruit'
};