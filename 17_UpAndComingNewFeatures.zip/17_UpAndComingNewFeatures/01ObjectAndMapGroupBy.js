//The difference between Object.groupBy() and Map.groupBy() is:
// - Object.groupBy() groups elements into a JavaScript object.
// - Map.groupBy() groups elements into a Map object.
// A Map object in JavaScript is a collection of key-value pairs where both keys and values can be of any data type. 
// Unlike plain objects, which only allow strings and symbols as keys, Maps allow for more flexibility with key types.

const planets = [
    {name:"Mercury", distance:58},
    {name:"Venus", distance:108},
    {name:"Earth", distance:150},
    {name:"Mars", distance:228},
    {name:"Jupiter", distance:779},
    {name:"Saturn", distance:1400},
    {name:"Uranus", distance:2900},
    {name:"Neptune", distance:4500}
  ];
  console.log("Planet distances from the Sun in millions of kilometres: ");
  
  // Callback function to Group Elements
  function myCallback({ distance }) {
    return distance < 500 ? "inner" : "outer";
  }
  
  // Stock Level Check: Group by distance
  console.log("\nUsing Object.groupby()");
  const result = Object.groupBy(planets, myCallback);

  // Display Results

let text ="\nInner planets: \n";
for (let [x,y] of result.inner.entries()) {
  text += y.name + " " + y.distance + "\n";
}

text += "\nOuter planets: \n";
for (let [x,y] of result.outer.entries()) {
  text += y.name + " " + y.distance + "\n";
}

console.log(text);

// Stock Level Check: Group by distance
console.log("\nUsing Map.groupby()");
const map_result = Map.groupBy(planets, myCallback);

// Display Results
let map_text ="\nInner planets: \n";
for (let x of map_result.get("inner")) {
  map_text += x.name + " " + x.distance + "\n";
}
map_text += "\nOuter planets: \n";
for (let x of map_result.get("outer")) {
  map_text += x.name + " " + x.distance + "\n";
}

console.log(map_text);
  