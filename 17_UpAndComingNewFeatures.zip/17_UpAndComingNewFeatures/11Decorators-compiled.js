"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var _class, _class3;
function _callSuper(t, o, e) { return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e)); }
function _possibleConstructorReturn(t, e) { if (e && ("object" == _typeof(e) || "function" == typeof e)) return e; if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined"); return _assertThisInitialized(t); }
function _assertThisInitialized(e) { if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); return e; }
function _isNativeReflectConstruct() { try { var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); } catch (t) {} return (_isNativeReflectConstruct = function _isNativeReflectConstruct() { return !!t; })(); }
function _getPrototypeOf(t) { return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) { return t.__proto__ || Object.getPrototypeOf(t); }, _getPrototypeOf(t); }
function _inherits(t, e) { if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function"); t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e); }
function _setPrototypeOf(t, e) { return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) { return t.__proto__ = e, t; }, _setPrototypeOf(t, e); }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _applyDecoratedDescriptor(i, e, r, n, l) { var a = {}; return Object.keys(n).forEach(function (i) { a[i] = n[i]; }), a.enumerable = !!a.enumerable, a.configurable = !!a.configurable, ("value" in a || a.initializer) && (a.writable = !0), a = r.slice().reverse().reduce(function (r, n) { return n(i, e, r) || r; }, a), l && void 0 !== a.initializer && (a.value = a.initializer ? a.initializer.call(l) : void 0, a.initializer = void 0), void 0 === a.initializer ? (Object.defineProperty(i, e, a), null) : a; }
/**
 * A decorator function that logs the method name and its arguments
 * whenever the decorated method is called.
 *
 * @param {Object} target - The target object.
 * @param {string} key - The name of the method being decorated.
 * @param {Object} descriptor - The property descriptor of the method.
 * @returns {Object} The modified property descriptor with the logging functionality.
 */
function log(target, key, descriptor) {
  var originalMethod = descriptor.value;
  descriptor.value = function () {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    console.log("Before ".concat(key, " has been called with arguments:"), args);
    var result = originalMethod.apply(this, args);
    console.log("After ".concat(key, " has been called with arguments:"), args);
    return result;
  };
  return descriptor;
}
function measureTime(target, key, descriptor) {
  var originalMethod = descriptor.value;
  descriptor.value = function () {
    var start = performance.now();
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    var result = originalMethod.apply(this, args);
    var end = performance.now();
    console.log("Execution time for ".concat(key, ": ").concat(((end - start) / 1000).toFixed(3), " seconds"));
    return result;
  };
  return descriptor;
}
var Example = (_class = /*#__PURE__*/function () {
  function Example() {
    _classCallCheck(this, Example);
  }
  return _createClass(Example, [{
    key: "sayHello",
    value: function sayHello(name) {
      console.log("Hello, ".concat(name, "!"));
      // Simulate a heavy computation
      for (var i = 0; i < 5000000000; i++) {}
    }
  }, {
    key: "sayGoodbye",
    value: function sayGoodbye(name) {
      console.log("Goodbye, ".concat(name, "!"));
    }
  }]);
}(), _applyDecoratedDescriptor(_class.prototype, "sayHello", [log, measureTime], Object.getOwnPropertyDescriptor(_class.prototype, "sayHello"), _class.prototype), _applyDecoratedDescriptor(_class.prototype, "sayGoodbye", [log], Object.getOwnPropertyDescriptor(_class.prototype, "sayGoodbye"), _class.prototype), _class);
var e = new Example();
e.sayHello("Bob");
e.sayGoodbye("Bob");
// Output:
// Before sayHello has been called with arguments: [ 'Bob' ]
// Hello, Bob!
// After sayHello has been called with arguments: [ 'Bob' ]
// Before sayGoodbye has been called with arguments: [ 'Bob' ]
// Goodbye, Bob!
// After sayGoodbye has been called with arguments: [ 'Bob' ]

//The @readonly decorator syntax is not yet natively supported in all JavaScript environments. 
// To use decorators, you need to enable experimental support for them in your environment. 
// If you are using Babel, you can enable the decorators plugin.

//First, install the necessary Babel packages:
// npm install --save-dev @babel/core @babel/cli @babel/preset-env @babel/plugin-proposal-decorators

//Next, create a Babel configuration file (.babelrc) in your project root with the following content:
//{
//     "presets": ["@babel/preset-env"],
//     "plugins": [["@babel/plugin-proposal-decorators", { "legacy": true }]]
//   }

//Then, update your package.json to include a build script:
// {
//     "scripts": {
//       "build": "babel Decorators.js -o Decorators-compiled.js"
//     }
// }
//Step 0: To Bulid and Run:
// edit package.json to include "build": "babel Decorators.js -o Decorators-compiled.js"
// in Command console enter: npm run build
// and then: node Decorators-compiled.js

//Basic Class Decorator Example
// Define a class decorator
function logger(targetClass) {
  // Modify the class by adding a log method
  return /*#__PURE__*/function (_targetClass) {
    function _class2() {
      _classCallCheck(this, _class2);
      return _callSuper(this, _class2, arguments);
    }
    _inherits(_class2, _targetClass);
    return _createClass(_class2, [{
      key: "log",
      value: function log() {
        console.log("Logging from ".concat(targetClass.name));
      }
    }]);
  }(targetClass);
}

// Use the decorator
var MyClass = logger(_class3 = /*#__PURE__*/_createClass(function MyClass() {
  _classCallCheck(this, MyClass);
  this.name = 'MyClass';
})) || _class3;
var instance = new MyClass();
instance.log(); // Output: Logging from MyClass

//Method Decorator Example
// Define a method decorator
function readonly(target, key, descriptor) {
  descriptor.writable = false;
  return descriptor;
}
var Greeting = /*#__PURE__*/function () {
  function Greeting() {
    _classCallCheck(this, Greeting);
  }
  return _createClass(Greeting, [{
    key: "sayHello",
    value:
    //@readonly
    function sayHello() {
      return 'Hello, my friends!';
    }
  }]);
}();
var greeting = new Greeting();
console.log(greeting.sayHello()); // Output: Hello, my friends!

// If @readonly decorator is included, trying to override the method will throw an error in strict mode
greeting.sayHello = function () {
  return 'Hi!';
}; // Error: Cannot assign to read only property 'sayHello'
console.log(greeting.sayHello()); // Output: Hi!

//Property Decorator Example - DOES NOT WORK!
// // Define a property decorator
// function observable(target, key) {
//     let value = target[key];

//     const getter = () => {
//       console.log(`Getting value: ${key}, ${value}`);
//       return value;
//     };

//     const setter = (newValue) => {
//       console.log(`Setting value: ${key}, ${newValue}`);
//       value = newValue;
//     };

//     Object.defineProperty(target, key, {
//       get: getter,
//       set: setter,
//       enumerable: true,
//       configurable: true,
//     });
// }

// class Task {
//     @observable
//     title = 'New Task';

//     //@observable
//     completed = false;
// }

//   const task = new Task();
//   task.title = 'Learn Decorators'; // Output: Setting value: Learn Decorators
//   console.log(task.title); // Output: Getting value: Learn Decorators

// function logProperty(target, key) {
//     let value = target[key];
//     console.log("BOO!");

//     const getter = () => {
//       console.log(`Getting value of ${key}: ${value}`);
//       return value;
//     };

//     const setter = (newValue) => {
//       console.log(`Setting value of ${key} to ${newValue}`);
//       value = newValue;
//     };

//     Object.defineProperty(target, key, {
//       get: getter,
//       set: setter,
//       enumerable: true,
//       configurable: true,
//     });
//   }

//   class Person {
//     @logProperty
//     name = 'Default Name'; // Initialize the property directly in the class body

//     constructor(name) {
//         if (name) {
//             this.name = name;
//           }
//     }
//   }

//   const person = new Person('Alice');
//   console.log(person.name); // Getting value of name: Alice
//   person.name = 'Bob';      // Setting value of name to Bob
//   console.log(person.name); // Getting value of name: Bob
