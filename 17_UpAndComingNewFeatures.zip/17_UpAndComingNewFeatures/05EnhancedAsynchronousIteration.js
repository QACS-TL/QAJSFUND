import { promises as fs } from 'fs';

async function* readLines(filePath) {
    // Implementation that returns an async iterable object
    const fileHandle = await fs.open(filePath, 'r');
    const fileStream = fileHandle.createReadStream();
    //To create an async iterable object, you need to implement the [Symbol.asyncIterator] method, 
    // which returns an object with a next method that returns a promise.
    const reader = fileStream[Symbol.asyncIterator]();
  
    try {
      let result;
      while (!(result = await reader.next()).done) {
        yield result.value.toString();
      }
    } finally {
      await fileHandle.close();
    }
  }
  
  async function processFile(filePath) {
    for await (const line of readLines(filePath)) {
      console.log(line);
    }
  }
  
  processFile('example.txt');
  