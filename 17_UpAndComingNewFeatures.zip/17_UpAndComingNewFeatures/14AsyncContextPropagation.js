//Async context propagation is a mechanism that allows data (such as request IDs, user sessions, or tracing metadata) 
//to persist across asynchronous operations, even when using callbacks, promises, or async/await.

//Node.js provides the AsyncLocalStorage API, which helps maintain context across async operations.
//The AsyncLocalStorage API is a part of the async_hooks module, which is used to monitor asynchronous operations in Node.js.
//Here are two (of a number of) methods AsyncLocalStorage API provides:
// - run(): Runs a callback function with a new context.
// - getStore(): Retrieves the current context.
//The context persists across await calls and nested async functions.
import { AsyncLocalStorage } from 'async_hooks';

const asyncLocalStorage = new AsyncLocalStorage();

function logWithRequestId(message) {
  const store = asyncLocalStorage.getStore();
  console.log(`[Request ID: ${store?.id}] ${message}`);
}

function handleRequest(reqId) {
  asyncLocalStorage.run({ id: reqId }, async () => {
    logWithRequestId("Processing request...");
    await new Promise(resolve => setTimeout(resolve, 1000));
    logWithRequestId("Request completed.");
  });
}

handleRequest(1234);
handleRequest(5678);
