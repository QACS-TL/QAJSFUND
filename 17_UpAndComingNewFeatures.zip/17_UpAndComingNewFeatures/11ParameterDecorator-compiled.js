"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var _class;
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _applyDecoratedDescriptor(i, e, r, n, l) { var a = {}; return Object.keys(n).forEach(function (i) { a[i] = n[i]; }), a.enumerable = !!a.enumerable, a.configurable = !!a.configurable, ("value" in a || a.initializer) && (a.writable = !0), a = r.slice().reverse().reduce(function (r, n) { return n(i, e, r) || r; }, a), l && void 0 !== a.initializer && (a.value = a.initializer ? a.initializer.call(l) : void 0, a.initializer = void 0), void 0 === a.initializer ? (Object.defineProperty(i, e, a), null) : a; }
/*
Step 1: Define the Decorator Function

First, you create a decorator function that will add the desired functionality to a method. 
The decorator takes the method and wraps it with additional logic.

*/

function logExecutionTime(target, key, descriptor) {
  var originalMethod = descriptor.value;
  descriptor.value = function () {
    var start = performance.now();
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    var result = originalMethod.apply(this, args);
    var end = performance.now();
    console.log("Function (".concat(key, ") Executed in ").concat(end - start, " ms"));
    return result;
  };
  return descriptor;
}

/*

Step 2: Apply the Decorator to a Class Method
Next, use the logExecutionTime decorator on a method within a class to measure and log its execution time.

*/
var TestClass = (_class = /*#__PURE__*/function () {
  function TestClass() {
    _classCallCheck(this, TestClass);
  }
  return _createClass(TestClass, [{
    key: "calculations",
    value: function calculations() {
      var sum = 0;
      for (var i = 0; i < 1e6; i++) {
        sum += i;
      }
      return sum;
    }
  }]);
}(), _applyDecoratedDescriptor(_class.prototype, "calculations", [logExecutionTime], Object.getOwnPropertyDescriptor(_class.prototype, "calculations"), _class.prototype), _class); // Instantiate the class and call the method
var ref = new TestClass();
ref.calculations();

/*

How It Works:
The logExecutionTime decorator wraps the  calculations() method.
Before and after executing the original method, it logs the execution start and end times, calculating the total time taken by the method.
When you call ref.calculations();, 
the decorator ensures that the time taken by the method is logged to the console.

*/
