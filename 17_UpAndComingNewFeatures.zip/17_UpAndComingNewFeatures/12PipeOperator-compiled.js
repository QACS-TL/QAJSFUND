"use strict";

var _ref, _, _ref2, _ref3, _QALimited, _ref4, _grossSalary, _ref6, _ref7, _postid;
var add = function add(x, y) {
  return x + y;
};
var square = function square(x) {
  return x * x;
};
var result = (_ref = (_ = 6, add(_, 3)), square(_ref));
console.log(result); // Output: 81

var toUpperCase = function toUpperCase(str) {
  return str.toUpperCase();
};
var reverseString = function reverseString(str) {
  return str.split('').reverse().join('');
};
var exclaim = function exclaim(str) {
  return "".concat(str, "!");
};
var result2 = (_ref2 = (_ref3 = (_QALimited = "QA Limited", toUpperCase(_QALimited)), reverseString(_ref3)), exclaim(_ref2));
console.log(result2); // Output: "DETIMIL AQ”

var calculateIncomeTax = function calculateIncomeTax(salary) {
  return salary * 0.25;
}; // 25% income tax
var calculateNI = function calculateNI(salary) {
  return salary * 0.075;
}; // 7.5% social security tax
var calculateNetSalary = function calculateNetSalary(salary, totalTaxes) {
  return salary - totalTaxes;
};

// Initial salary
var grossSalary = 1000;

// Using the pipe operator to calculate total taxes and then the net salary
var netSalary = (_ref4 = (_grossSalary = grossSalary, function (salary) {
  var incomeTax = calculateIncomeTax(salary);
  var ni = calculateNI(salary);
  var totalDeduction = incomeTax + ni;
  return {
    totalDeduction: totalDeduction,
    salary: salary
  };
}(_grossSalary)), function (_ref5) {
  var totalDeduction = _ref5.totalDeduction,
    salary = _ref5.salary;
  return calculateNetSalary(salary, totalDeduction);
}(_ref4));
console.log("Net Salary: $".concat(netSalary.toFixed(2))); // Output: Net Salary: $675.00

// working code
var fetchUserData = function fetchUserData(postid) {
  return fetch("https://jsonplaceholder.typicode.com/comments/".concat(postid)).then(function (res) {
    return res.json();
  });
};
var getData = function getData(post) {
  return "".concat(post.name, " ").concat(post.email);
};
var upperData = function upperData(name) {
  return name.toUpperCase();
};
var postid = 1;
var result3 = (_ref6 = (_ref7 = (_postid = postid, fetchUserData(_postid) // Fetch user data asynchronously
), _ref7.then(getData) // Get data
), _ref6.then(upperData)); // Convert data to uppercase

result3.then(console.log); // Output: ID LABORE EX ET QUAM LABORUM ELISEO@GARDNER.BIZ
