// Promise.withResolvers replaces code like the following:
let resolve_old, reject_old;

const promise_old = new Promise((res, rej) => {
  resolve_old = res;
  reject_old = rej;
});

promise_old
  .then(value => {
      console.log('Old Resolved with:', value);
   })
  .catch(error => {
      console.error('Old Rejected with:', error);
  });

Math.random() > 0.5 ? resolve_old("old ok") : reject_old("old not ok");

//console.log(promise_old);

//with:

const { promise, resolve, reject } = Promise.withResolvers();
 
promise
  .then(value => {
    console.log('Resolved with:', value);
  })
  .catch(error => {
    console.error('Rejected with:', error);
  });

Math.random() > 0.5 ? resolve("ok") : reject("not ok");

//resolve("Success");