"use strict";

function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var _class, _descriptor;
function _initializerDefineProperty(e, i, r, l) { r && Object.defineProperty(e, i, { enumerable: r.enumerable, configurable: r.configurable, writable: r.writable, value: r.initializer ? r.initializer.call(l) : void 0 }); }
function _defineProperties(e, r) { for (var t = 0; t < r.length; t++) { var o = r[t]; o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o); } }
function _createClass(e, r, t) { return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e; }
function _classCallCheck(a, n) { if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function"); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _applyDecoratedDescriptor(i, e, r, n, l) { var a = {}; return Object.keys(n).forEach(function (i) { a[i] = n[i]; }), a.enumerable = !!a.enumerable, a.configurable = !!a.configurable, ("value" in a || a.initializer) && (a.writable = !0), a = r.slice().reverse().reduce(function (r, n) { return n(i, e, r) || r; }, a), l && void 0 !== a.initializer && (a.value = a.initializer ? a.initializer.call(l) : void 0, a.initializer = void 0), void 0 === a.initializer ? (Object.defineProperty(i, e, a), null) : a; }
function _initializerWarningHelper(r, e) { throw Error("Decorating class property failed. Please ensure that transform-class-properties is enabled and runs after the decorators transform."); }
/*
npm install --save-dev @babel/plugin-proposal-decorators @babel/plugin-proposal-class-properties
npm install --save-dev @babel/core @babel/cli @babel/preset-env @babel/plugin-proposal-decorators @babel/plugin-proposal-class-properties
Here's an example of using a decorator on a class property (variable) to automatically log any changes 
made to it.

*/

/* Step 1: Define the Decorator Function

The decorator will be responsible for logging changes to the property.

*/

function logProperty(target, key) {
  var value = target[key];
  var getter = function getter() {
    console.log("Getting value of ".concat(key, ": ").concat(value));
    return value;
  };
  var setter = function setter(newValue) {
    console.log("Setting value of ".concat(key, " to ").concat(newValue));
    value = newValue;
  };

  // Replace the original property with a getter and setter
  Object.defineProperty(target, key, {
    get: getter,
    set: setter,
    enumerable: true,
    configurable: true
  });
}

/*

Step 2: Apply the Decorator to a Class Property (Variable)
Use the logProperty decorator to log access and changes to a property in a class.

*/
var Bank = (_class = /*#__PURE__*/_createClass(function Bank(value) {
  _classCallCheck(this, Bank);
  _initializerDefineProperty(this, "Deposite", _descriptor, this);
  this.Deposite = value;
}), _descriptor = _applyDecoratedDescriptor(_class.prototype, "Deposite", [logProperty], {
  configurable: true,
  enumerable: true,
  writable: true,
  initializer: null
}), _class); // Instantiate the class and interact with the property
var hsbc = new Bank(3000);

// Accessing the property
console.log(hsbc.Deposite);

// Modifying the property
hsbc.Deposite = 4000;

// Accessing again to see the new value
console.log(hsbc.Deposite);

/*
How It Works:
The logProperty decorator is applied to the myVariable property.
It wraps the property with a getter and setter, which log the property's access and modification.
The decorator is used to log every time the property is read or written to.

*/
