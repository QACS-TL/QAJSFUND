// The Temporal API offers a modern approach to handling dates and times in JavaScript, 
// addressing many of the limitations of the existing Date object. 
// It provides a comprehensive suite of classes and methods for precise and unambiguous date and time computations.
import { Temporal } from '@js-temporal/polyfill';
const now = Temporal.Now.plainDateTimeISO();
console.log(now.toString()); // e.g., '2026-02-28T11:46:42.123456789'

const date = Temporal.PlainDate.from('2026-02-28');
console.log(date.toString()); // "2026-02-28"

// The Temporal API includes classes such as Temporal.PlainDate, Temporal.PlainTime, Temporal.PlainMonthDay, 
// and Temporal.PlainYearMonth, 
// enabling developers to work with dates and times without the quirks associated with the traditional Date object.
const today = Temporal.PlainDate.from('2024-08-09');
console.log(today.toString()); // Output: 2024-08-09
const tomorrow = today.add({ days: 1 });
console.log(tomorrow.toString()); // Output: 2024-08-10

const startDate1 = Temporal.PlainDate.from('2024-10-01');
const endDate1 = startDate1.add({ days: 7 });
console.log("Start date of the project:",startDate1.toString()); 
console.log("End date of the project:",endDate1.toString()); 

// Add 5 days to a given date
const original_date = Temporal.PlainDate.from('2025-02-28');
const newDate = original_date.add({ days: 5 });
console.log(`New date after adding 5 days: ${newDate}`); // Output: 2025-03-05

// Subtract 3 months from the date
const earlierDate = date.subtract({ months: 3 });
console.log(`Date after subtracting 3 months: ${earlierDate}`); // Output: 2024-05-13


// Create a Temporal.PlainTime for a specific time
const time = Temporal.PlainTime.from('15:30:00');
console.log(`The time is: ${time}`); // Output: 15:30:00

// Add hours and minutes to a time
const newTime = time.add({ hours: 1, minutes: 30 });
console.log(`New time after adding 1 hour and 30 minutes: ${newTime}`); // Output: 17:00:00

// Create a Temporal.ZonedDateTime in a specific time zone
const zonedDateTime = Temporal.ZonedDateTime.from('2025-02-28T15:30:00+00:00[Europe/London]');
console.log(`Zoned Date and Time: ${zonedDateTime}`); // Output: 2025-02-28T17:30:00+00:00[Europe/London]

// Convert to a different time zone
const newZonedDateTime = zonedDateTime.withTimeZone('America/New_York');
console.log(`Converted to New York time: ${newZonedDateTime}`); // Output: 2025-02-28T12:30:00-05:00[America/New_York]

// Calculate the difference between two dates
const startDate2 = Temporal.PlainDate.from('2025-02-28');
const endDate2 = Temporal.PlainDate.from('2025-04-28');
const duration = endDate2.since(startDate2);
console.log(`Duration between dates: ${duration}`); // Output: P59D (59 days)

// Add that duration to another date
const newEndDate = startDate2.add(duration);
console.log(`New end date after adding duration: ${newEndDate}`); // Output: 2025-04-28


