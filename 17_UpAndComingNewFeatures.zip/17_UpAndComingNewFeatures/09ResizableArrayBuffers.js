//The resize() method of ArrayBuffer instances resizes the ArrayBuffer to the specified size, in bytes.
const buf = new ArrayBuffer(16, {maxByteLength: 32});
// `typedArray` starts at offset 2
console.log(buf.byteLength); // Expected output: 16

buf.resize(12);

console.log(buf.byteLength); // Expected output: 12

buf.resize(32);

console.log(buf.byteLength); // Expected output: 32

try {
  buf.resize(64); // Expected RangeError: ArrayBuffer.prototype.resize: Invalid length parameter
}
catch (e) {
  console.log(e.message);
}

console.log(buf.byteLength); // Expected output: 32

//****************************
//ArrayBuffer transfer method
//****************************
// Create an ArrayBuffer and write a few bytes
const buffer = new ArrayBuffer(8);
const view = new Uint8Array(buffer);
view[0] = 2;
view[7] = 4;

//The transfer() method of ArrayBuffer instances creates a new ArrayBuffer with the same byte content as this buffer, then detaches this buffer.

//The byteLength of the new ArrayBuffer. Defaults to the byteLength of this ArrayBuffer.
// - If newByteLength is smaller than the byteLength of this ArrayBuffer, the "overflowing" bytes are dropped.
// - If newByteLength is larger than the byteLength of this ArrayBuffer, the extra bytes are filled with zeros.
// - If this ArrayBuffer is resizable, newByteLength must not be greater than its maxByteLength.

// Copy the buffer to the same size
const buffer2 = buffer.transfer();
//The detached property is an accessor property whose set accessor function is undefined, meaning that you can only read this property. 
// The value is false when the ArrayBuffer is first created. The value becomes true if the ArrayBuffer is transferred, 
// which detaches the instance from its underlying memory. Once a buffer becomes detached, it is no longer usable.
console.log(buffer.detached); // true
console.log(buffer.byteLength); // Expected output: 0 (indicating  the buffer is no longer usable)
try{
  console.log(buffer.byteLength); // Expected output: 0
}
catch(e){
    console.log(e.message);
}

console.log(buffer2.byteLength); // 8
const view2 = new Uint8Array(buffer2);
console.log(view2[0]); // 2
console.log(view2[7]); // 4

// Copy the buffer to a smaller size

const buffer3 = buffer2.transfer(4);
console.log(buffer3.byteLength); // 4
const view3 = new Uint8Array(buffer3);
console.log(view3[0]); // 2
console.log(view3[7]); // undefined

// Copy the buffer to a larger size
const buffer4 = buffer3.transfer(8);
console.log(buffer4.byteLength); // 8
const view4 = new Uint8Array(buffer4);
console.log(view4[0]); // 2
console.log(view4[7]); // 0

// Already detached, throws TypeError
try {
  buffer3.transfer(); // TypeError: Cannot perform ArrayBuffer.prototype.transfer on a detached ArrayBuffer
}
catch (e) {
  console.log(e.message);
}
