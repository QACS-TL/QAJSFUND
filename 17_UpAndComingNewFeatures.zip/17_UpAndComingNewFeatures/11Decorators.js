//NOTE: (Decorators are currently a Stage‑2+ proposal and may still change, 
// but are usable today through transpilers like Babel or in TypeScript. (see below))

/**
 * A decorator function that logs the method name and its arguments
 * whenever the decorated method is called.
 *
 * @param {Object} target - The target object.
 * @param {string} key - The name of the method being decorated.
 * @param {Object} descriptor - The property descriptor of the method.
 * @returns {Object} The modified property descriptor with the logging functionality.
 */
function log(target, key, descriptor) {
  const originalMethod = descriptor.value;
  
  descriptor.value = function (...args) {
    console.log(`Before ${key} has been called with arguments:`, args);
    const result =  originalMethod.apply(this, args);
    console.log(`After ${key} has been called with arguments:`, args);
    return result;
  };

  return descriptor;
}

function measureTime(target, key, descriptor) {
  const originalMethod = descriptor.value;
  descriptor.value = function (...args) {
    const start = performance.now();
    const result = originalMethod.apply(this, args);
    const end = performance.now();
    console.log(`Execution time for ${key}: ${((end - start)/1000).toFixed(3)} seconds`);
    return result;
  };
  return descriptor;
}

class Example {
  @log
  @measureTime
  sayHello(name) {
    console.log(`Hello, ${name}!`);
    // Simulate a heavy computation
    for (let i = 0; i < 5000000000; i++) {}
  }

  @log
  sayGoodbye(name) {
    console.log(`Goodbye, ${name}!`);
  }
}

const e = new Example();
e.sayHello("Bob");
e.sayGoodbye("Bob");
// Output:
// Before sayHello has been called with arguments: [ 'Bob' ]
// Hello, Bob!
// After sayHello has been called with arguments: [ 'Bob' ]
// Before sayGoodbye has been called with arguments: [ 'Bob' ]
// Goodbye, Bob!
// After sayGoodbye has been called with arguments: [ 'Bob' ]


//The @readonly decorator syntax is not yet natively supported in all JavaScript environments. 

// To use decorators, you need to enable experimental support for them in your environment. 
// If you are using Babel, you can enable the decorators plugin.

//First, install the necessary Babel packages:
// npm install --save-dev @babel/core @babel/cli @babel/preset-env @babel/plugin-proposal-decorators

//Next, create a Babel configuration file (.babelrc) in your project root with the following content:
//{
//     "presets": ["@babel/preset-env"],
//     "plugins": [["@babel/plugin-proposal-decorators", { "legacy": true }]]
//   }

//Then, update your package.json to include a build script:
// {
//     "scripts": {
//       "build": "babel Decorators.js -o Decorators-compiled.js"
//     }
// }
//Step 0: To Build and Run:
// edit package.json to include "build": "babel Decorators.js -o Decorators-compiled.js"
// in Command console enter: npm run build
// and then: node Decorators-compiled.js

//Basic Class Decorator Example
// Define a class decorator
function logger(targetClass) {
    // Modify the class by adding a log method
    return class extends targetClass {
      log() {
        console.log(`Logging from ${targetClass.name}`);
      }
    };
}
  
// Use the decorator
@logger
class MyClass {
    constructor() {
      this.name = 'MyClass';
    }
}

const instance = new MyClass();
instance.log(); // Output: Logging from MyClass

//Method Decorator Example
// Define a method decorator
function readonly(target, key, descriptor) {
    descriptor.writable = false;
    return descriptor;
}
  
class Greeting {
    //@readonly
    sayHello() {
      return 'Hello, my friends!';
    }
}
  
const greeting = new Greeting();
console.log(greeting.sayHello()); // Output: Hello, my friends!

// If @readonly decorator is included, trying to override the method will throw an error in strict mode
greeting.sayHello = function() { return 'Hi!' }; // Error: Cannot assign to read only property 'sayHello'
console.log(greeting.sayHello()); // Output: Hi!
  
//Property Decorator Example - DOES NOT WORK!
// // Define a property decorator
// function observable(target, key) {
//     let value = target[key];
  
//     const getter = () => {
//       console.log(`Getting value: ${key}, ${value}`);
//       return value;
//     };
  
//     const setter = (newValue) => {
//       console.log(`Setting value: ${key}, ${newValue}`);
//       value = newValue;
//     };
  
//     Object.defineProperty(target, key, {
//       get: getter,
//       set: setter,
//       enumerable: true,
//       configurable: true,
//     });
// }
  
// class Task {
//     @observable
//     title = 'New Task';
  
//     //@observable
//     completed = false;
// }
  
//   const task = new Task();
//   task.title = 'Learn Decorators'; // Output: Setting value: Learn Decorators
//   console.log(task.title); // Output: Getting value: Learn Decorators
  
// function logProperty(target, key) {
//     let value = target[key];
//     console.log("BOO!");
  
//     const getter = () => {
//       console.log(`Getting value of ${key}: ${value}`);
//       return value;
//     };
  
//     const setter = (newValue) => {
//       console.log(`Setting value of ${key} to ${newValue}`);
//       value = newValue;
//     };
  
//     Object.defineProperty(target, key, {
//       get: getter,
//       set: setter,
//       enumerable: true,
//       configurable: true,
//     });
//   }
  
//   class Person {
//     @logProperty
//     name = 'Default Name'; // Initialize the property directly in the class body
  
//     constructor(name) {
//         if (name) {
//             this.name = name;
//           }
//     }
//   }
  
//   const person = new Person('Alice');
//   console.log(person.name); // Getting value of name: Alice
//   person.name = 'Bob';      // Setting value of name to Bob
//   console.log(person.name); // Getting value of name: Bob
  
  

