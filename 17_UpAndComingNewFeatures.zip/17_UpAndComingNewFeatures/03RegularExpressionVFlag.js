
//Back ground:
// A codePoint is the character located at a specified location:

const s = "Hello";
console.log(s.codePointAt(1)); // 101 = 'e'

// With single characters the codePointAt(x) parameter (x in this example) must always be a zero

//The letter A is represented by the code point 65 (in decimal), or 41 (in hexadecimal).
// From string to decimal code point
console.log('A'.codePointAt(0)) // 65

// From decimal to hexadecimal code point
console.log(Number(65).toString(16)); //41

// From hexadecimal to decimal code point
console.log(parseInt('41',16)) //65
// alternatively
console.log(0x0041); //65

// From decimal code point to string
console.log(String.fromCodePoint(65)); //'A'

// From hexadecimal code point to string
console.log('\u0041'); //'A'


// The Unicode Standard assigns various properties and property values to every symbol. 
// For example, to get the set of symbols that are used in the Greek script, 
// search the Unicode database for symbols whose Script_Extensions property value includes Greek.

// ES2018 Unicode character property escapes make it possible to access these Unicode character properties 
// natively in ECMAScript regular expressions. 
// For example, the pattern \p{Script_Extensions=Greek} matches every symbol that is used in the Greek script:
const regexGreekSymbol = /\p{Script_Extensions=Greek}/u;
console.log(regexGreekSymbol.test('π'));
// → true ✅
console.log(regexGreekSymbol.test('£'));
// → false ❌

console.log("*********************************************************************");
// By definition, Unicode character properties expand to a set of code points, and can thus be transpiled as a 
// character class containing the code points they match individually. 
// For example, \p{ASCII_Hex_Digit} is equivalent to [0-9A-Fa-f]: it only ever matches a single Unicode character/code point at a time. 
// In some situations, this is insufficient:

// using the u flag (it indicates inspection of a unicode character)
// Unicode defines a character property named “Emoji”.
const reEmoji = /^\p{Emoji}$/u;

// Match an emoji that consists of just 1 code point:
console.log(reEmoji.test('⚽')); // '\u26BD'
// → true ✅

// Match an emoji that consists of multiple code points:
console.log(reEmoji.test('👨🏾‍⚕️')); // '\u{1F468}\u{1F3FE}\u200D\u2695\uFE0F'
// → false ❌


console.log("*********************************************************************");
// The v flag is an "upgrade" to the u flag that enables more Unicode-related features.
// The u and v flags in JavaScript regular expressions are both related to Unicode handling, but they behave very differently.
// The v flag is newer (ES2024) and introduces Unicode set notation and much more powerful, precise Unicode matching.

// Unicode defines a character property named “Emoji”.
const reEmojiv = /^\p{Emoji}$/v;

// Match an emoji that consists of just 1 code point:
console.log(reEmojiv.test('⚽')); // '\u26BD'
// → true ✅

// Match an emoji that consists of multiple code points:
console.log(reEmojiv.test('👨🏾‍⚕️')); // '\u{1F468}\u{1F3FE}\u200D\u2695\uFE0F'
// → false ❌

console.log("*********************************************************************");

console.log('\u{1F468}');
console.log('\u{1F468}');
console.log(reEmoji.test('\u{1F468}')); // → true

console.log('\u{1F468}\u{1F3FE}');
console.log('\u{1F3FE}');
console.log(reEmoji.test('\u{1F3FE}')); // → true

console.log('\u200D');
console.log('\u{1F468}\u{1F3FE}\u200D');
console.log(reEmoji.test('\u200D')); // → false

console.log('\u2695');
console.log('\u{1F468}\u{1F3FE}\u200D\u2695');
console.log(reEmoji.test('\u2695')); // → true

console.log('\uFE0F');
console.log('\u{1F468}\u{1F3FE}\u200D\u2695\uFE0F');
console.log(reEmoji.test('\uFE0F')); // → false

console.log("*********************************************************************");
//In the above example, the regular expression doesn’t match the 👨🏾‍⚕️ emoji because it happens to consist of multiple code points, 
// and Emoji is a Unicode character property.

//Luckily, the Unicode Standard also defines several properties of strings. Such properties expand to a set of strings, 
// each of which contains one or more code points. In regular expressions, properties of strings translate to a set of alternatives. 
// To illustrate this, imagine a Unicode property that applies to the strings 'a', 'b', 'c', 'W', 'xy', and 'xyz'. 
// This property translates to either of the following regular expression patterns (using alternation):
//    xyz|xy|a|b|c|W or xyz|xy|[a-cW]. (Longest strings first, so that a prefix like 'xy' does not hide a longer string like 'xyz'.) 
// Unlike existing Unicode property escapes, this pattern can match multi-character strings. Here’s an example of a property of strings in use:

const re = /^\p{RGI_Emoji}$/v;

// Match an emoji that consists of just 1 code point:
console.log(re.test('⚽')); // '\u26BD'
// → true ✅

// Match an emoji that consists of multiple code points:
console.log(re.test('👨🏾‍⚕️')); // '\u{1F468}\u{1F3FE}\u200D\u2695\uFE0F'
// → true ✅

//This code snippet refers to the property of strings RGI_Emoji, which Unicode defines as 
// “the subset of all valid emoji (characters and sequences) recommended for general interchange”. 
// With this, we can now match emoji regardless of how many code points they consist of under the hood!
//The v flag enables support for the following Unicode properties of strings from the get-go:

// Basic_Emoji
// Emoji_Keycap_Sequence
// RGI_Emoji_Modifier_Sequence
// RGI_Emoji_Flag_Sequence
// RGI_Emoji_Tag_Sequence
// RGI_Emoji_ZWJ_Sequence
// RGI_Emoji