//NB DOES NOT WORK
/*
npm install --save-dev @babel/plugin-proposal-decorators @babel/plugin-proposal-class-properties
npm install --save-dev @babel/core @babel/cli @babel/preset-env @babel/plugin-proposal-decorators @babel/plugin-proposal-class-properties
Here's an example of using a decorator on a class property (variable) to automatically log any changes 
made to it.

*/
//Step 0: ToBuild and Run:
// edit package.json to include "build": "babel PropertyDecorator.js -o PropertyDecorator-compiled.js"
// in Command console enter: npm run build
// and then: node PropertyDecorator-compiled.js

/* Step 1: Define the Decorator Function

The decorator will be responsible for logging changes to the property.

*/

function logProperty(target, key) {

    
    let value = target[key];

    const getter = function() {
        console.log(`Getting value of ${key}: ${value}`);
        return value;
    };

    const setter = function(newValue) {
        console.log(`Setting value of ${key} to ${newValue}`);
        value = newValue;
    };

    // Replace the original property with a getter and setter
    Object.defineProperty(target, key, {
        get: getter,
        set: setter,
        enumerable: true,
        configurable: true,
    });
}

/*

Step 2: Apply the Decorator to a Class Property (Variable)
Use the logProperty decorator to log access and changes to a property in a class.

*/

class Bank {
    @logProperty
    Deposit;

    constructor(value) {
        this.Deposit = value;
    }
}

// Instantiate the class and interact with the property
const hsbc = new Bank(3000);

// Accessing the property
console.log(hsbc.Deposit);

// Modifying the property
hsbc.Deposit = 4000;

// Accessing again to see the new value
console.log(hsbc.Deposit);

/*
How It Works:
The logProperty decorator is applied to the myVariable property.
It wraps the property with a getter and setter, which log the property's access and modification.
The decorator is used to log every time the property is read or written to.

*/
