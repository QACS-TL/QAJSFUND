

//Step 0: To Bulid and Run:
// edit package.json to include "build": "babel ParameterDecorator.js -o ParameterDecorator-compiled.js"
// in Command console enter: npm run build
// and then: node ParameterDecorator-compiled.js

/*
Step 1: Define the Decorator Function


First, you create a decorator function that will add the desired functionality to a method. 
The decorator takes the method and wraps it with additional logic.

*/

function logExecutionTime(target, key, descriptor) {
    const originalMethod = descriptor.value;

    descriptor.value = function(...args) {
        
        const start = performance.now();
        const result = originalMethod.apply(this, args);
        const end = performance.now();
        console.log(`Function (${key}) Executed in ${end - start} ms`);
        return result;
    };

    return descriptor;
}

/*

Step 2: Apply the Decorator to a Class Method
Next, use the logExecutionTime decorator on a method within a class to measure and log its execution time.

*/
class TestClass {
    @logExecutionTime
    calculations() {
        
        let sum = 0;
        for (let i = 0; i < 1e6; i++) {
            sum += i;
        }
        return sum;
    }
}

// Instantiate the class and call the method
const ref = new TestClass();
ref.calculations();

/*

How It Works:
The logExecutionTime decorator wraps the  calculations() method.
Before and after executing the original method, it logs the execution start and end times, calculating the total time taken by the method.
When you call ref.calculations();, 
the decorator ensures that the time taken by the method is logged to the console.

*/
