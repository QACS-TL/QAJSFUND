const add = (x, y) => x + y;
const square = x => x * x;

const result = 6 |> (x => add(x, 3)) |> square;
console.log(result); // Output: 81


const toUpperCase = str => str.toUpperCase(); 
const reverseString = str => str.split('').reverse().join(''); 
const exclaim = str => `${str}!`; 

const result2 = "QA Limited" |> toUpperCase |> reverseString |> exclaim; 
console.log(result2); // Output: "DETIMIL AQ”


const calculateIncomeTax = salary => salary * 0.25; // 25% income tax
const calculateNI = salary => salary * 0.075; // 7.5% social security tax
const calculateNetSalary = (salary, totalTaxes) => salary - totalTaxes;

// Initial salary
const grossSalary = 1000; 

// Using the pipe operator to calculate total taxes and then the net salary
const netSalary = grossSalary |> (salary=> {
        const incomeTax = calculateIncomeTax(salary);
        const ni=calculateNI(salary);
        const totalDeduction = incomeTax+ni;
        return  {totalDeduction,salary};
     })
  |> ( ({totalDeduction,salary})  => calculateNetSalary(salary, totalDeduction));

console.log(`Net Salary: $${netSalary.toFixed(2)}`); // Output: Net Salary: $675.00


// working code
const fetchUserData = postid => fetch(`https://jsonplaceholder.typicode.com/comments/${postid}`).then(res => res.json());
const getData = post => `${post.name} ${post.email}`;
const upperData = name => name.toUpperCase();

const postid = 1;

const result3 = postid
  |> fetchUserData                                // Fetch user data asynchronously
  |> (dataPromise => dataPromise.then(getData))  // Get data
  |> (upperDataPromise => upperDataPromise.then(upperData));   // Convert data to uppercase

result3.then(console.log); // Output: ID LABORE EX ET QUAM LABORUM ELISEO@GARDNER.BIZ
