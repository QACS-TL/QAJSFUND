//NOTE: The pattern matching feature is still in the proposal stage and may not have an official Babel plugin yet

//The match expression is a proposed feature for JavaScript and is not yet natively supported in most JavaScript environments. 
//It is a powerful and flexible pattern matching syntax that allows you to match values against patterns and extract parts of 
// the value based on the pattern.
const day = 2;

const result = match (day) {
    when (1) { "It's Sunday" }
    when (2) { "It's Monday" }
    when (3) { "It's Tuesday" }
    when (4) { "It's Wednesday" }
    when (5) { "It's Thursday" }
    when (6) { "It's Friday" }

  otherwise { "its SUNDAY" }
};

console.log(result); // Output: "It's Monday"


//This example tests a "response" object against several patterns, branching based on the .status property, 
//and extracting different parts from the response in each branch to process in various handler functions.
res = fetch("https://jsonplaceholder.typicode.com/posts/1");
match (res) {
  when { status: 200, let body, ...let rest }: handleData(body, rest);
  when { const status, destination: let url } 
         and if (300 <= status && status < 400):
    handleRedirect(url);
  when { status: 500 } and if (!this.hasRetried): do {
    retry(req);
    this.hasRetried = true;
  };
  default: throwSomething();
}


//This sample is a contrived parser for a text-based adventure game.
//The first match arm matches if the command is an array with exactly two items. 
//The first must be exactly the string 'go', and the second must be one of the given cardinal directions. 
//Note the use of the and pattern to bind the second item in the array to dir using a binding pattern 
//before verifying (using the or pattern) that it’s one of the given directions.

//The second match arm is slightly more complex. 
//First, a regex pattern is used to verify that the object stringifies to "something ball", 
//then an object patterns verifies that it has a .weight property and binds it to weight, 
//so that the weight is available to the arm's expression.
command = ["go", "north"];
match (command) {
  when ['go', let dir and ('north' or 'east' or 'south' or 'west')]: go(dir);
  when ['take', /[a-z]+ ball/ and {let weight}: takeBall(weight);
  default: lookAround()
}



const data = {
  user: {
    name: "Tadas",
    address: { city: "Manchester", dept: "IT" }
  }
};

const result = match (data) {
  when ({ user: { name: "Tadas", address: { city: "Manchester" } } }) {
    "Tadas lives in Manchester"
  }
  when ({ user: { address: { city: "Manchester" } } }) {
    "User lives in Manchester"
  }
  otherwise {
    "User location unknown"
  }
};

console.log(result); 
