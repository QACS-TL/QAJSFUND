// Enhanced JSON Modules allow you to import JSON files directly into JavaScript using ES modules, eliminating the need for fs.readFileSync or fetch.
//In previous ECMAScript versions, developers relied on bundlers or loaders to import JSON files. 
// ES15 makes this part of the standard module system, simplifying configuration-heavy apps. 
// However, this change might break code that relies on older, non-standard ways of importing JSON, or if certain build tools are configured with older behaviors.

//Original approach before ES15
// import { readFileSync } from 'fs';

// const data = JSON.parse(readFileSync('./data.json', 'utf-8'));

// console.log(data.name);      // Output: ECMAScript
// console.log(data.version);   // Output: 2024
// console.log(data.features);  // Output: ["JSON Modules", "Promise.withResolvers", "Temporal API"]


// //ES15 approach
//Documentation suggests using assert { type: 'json' } but this has been replaced by with { type: 'json' }
//import data2 from './data.json' assert { type: 'json' }; 
import data2 from './data.json' with { type: 'json' };

console.log(data2.name);      // Output: ECMAScript
console.log(data2.version);   // Output: 2024
console.log(data2.features);  // Output: ["JSON Modules", "Promise.withResolvers", "Temporal API"]
