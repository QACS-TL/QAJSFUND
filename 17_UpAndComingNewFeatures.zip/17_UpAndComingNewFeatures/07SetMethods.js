//The JavaScript Set object is a collection of unique values. 
// It now has methods to perform set operations like union, intersection, difference, and more.

const setA = new Set([1, 2, 3]);
const setB = new Set([3, 4, 5]);
const setC = new Set([3, 4, 5, 6]);
const setD = new Set([4, 5]);

console.log(setA.union(setB));         // Set {size: , 1, 2, 3, 4, 5 }
console.log(setA.intersection(setB));  // Set {size: 1, 3 }
console.log(setA.difference(setB));    // Set {size: 2, 1, 2 }
console.log(setA.symmetricDifference(setB)); // Set {size: 4, 1, 2, 4, 5}
console.log(setA.isSubsetOf(setC)); // false
console.log(setB.isSubsetOf(setC)); // true
console.log(setC.isSupersetOf(setA)); // false
console.log(setC.isSupersetOf(setB)); // true
console.log(setB.isDisjointFrom(setD)); // false
console.log(setA.isDisjointFrom(setD)); // true

