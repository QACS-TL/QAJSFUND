/**
 * Demonstrates the usage of Atomics.waitAsync() method.
 * 
 * Atomics.waitAsync() is a static method that waits asynchronously on a shared memory location 
 * and returns a Promise representing the result of the operation.
 * Unlike Atomics.wait(), waitAsync is non-blocking and usable on the main thread.
 * 
 * Imagine you're writing a worker thread that should “pause” until the main thread says:
 * “Start now.”
 * Instead of:
 * constantly looping (“polling”)
 * wasting CPU
 * blocking with Atomics.wait()
 * You can use Atomics.waitAsync() to sleep without blocking, and wake when notified.
 */
//Atomic operations
// When memory is shared, multiple threads can read and write the same data in memory. Atomic operations make sure that predictable values are written and read, 
// that operations are finished before the next operation starts and that operations are not interrupted.

// The Atomics.waitAsync() static method waits asynchronously on a shared memory location and returns an object representing the result of the operation.
// Unlike Atomics.wait(), waitAsync is non-blocking and usable on the main thread.


//************************************************************************** */
// Import the Worker class
// We load Node’s worker_threads module, which lets us create worker threads.
import { Worker } from 'node:worker_threads';

// new Worker('./worker.js') launches a second JavaScript thread, running the code in worker.js.
// - The worker begins executing immediately in parallel.
// - The main thread continues running this file at the same time.
const worker = new Worker('./worker.js');

// Schedule a wake‑up message
// We set a timer for 1 second.
// After the second passes:
// - worker.postMessage("wake") sends a message to the worker thread.
// - The worker receives this message through parentPort.on("message", ...).
// This is how the main thread tells the worker:
//   “Time to wake up!”
setTimeout(() => {
  worker.postMessage("wake");
}, 2000);

//After setting the timer, main.js has nothing else to do.
// It will stay alive only because:
// - A worker thread exists (workers keep Node alive until they exit).
// When the worker thread eventually ends, Node also exits.