// The Promise.withResolvers() method simplifies the creation of promises by returning an object containing the promise itself, 
// along with its associated resolve and reject functions.
function createEventsAggregator(eventsCount) {
        const events = [];
        const { promise, resolve, reject } = Promise.withResolvers();
    
        return {
            add: (event) => {
                if (event === "rejected") reject("Event rejected.");
                if (events.length < eventsCount) events.push(event);
                if (events.length === eventsCount) resolve(events);
            },
            abort: () => reject("Events aggregation aborted."), 
            events: promise,
        };
    }

const eventsAggregator = createEventsAggregator(3);

eventsAggregator.events
    .then((events) => console.log("Resolved:", events))
    .catch((reason) => console.error("Rejected:", reason));

eventsAggregator.add("event-one");
eventsAggregator.add("event-two");
eventsAggregator.add("event-three");
// Resolved: [ "event-one", "event-two", "event-three" ]

const eventsAggregator2 = createEventsAggregator(3);

eventsAggregator2.events
    .then((events) => console.log("Resolved:", events))
    .catch((reason) => console.error("Rejected:", reason));

eventsAggregator2.add("event-one");
eventsAggregator2.add("rejected");
eventsAggregator2.add("event-two");
eventsAggregator2.add("event-three");
// Rejected: Bad event added.

const eventsAggregator3 = createEventsAggregator(3);

eventsAggregator3.events
.then((events) => console.log("Resolved:", events))
.catch((reason) => console.error("Rejected:", reason));

eventsAggregator3.add("event-one");
eventsAggregator3.abort();
eventsAggregator3.add("event-two");
eventsAggregator3.add("event-three");
// Rejected: Events aggregation aborted.


