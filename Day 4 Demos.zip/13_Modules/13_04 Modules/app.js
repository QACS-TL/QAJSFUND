//app.js
import {area, circumference} from "./circle-functions.js";

console.log(area(5)); //78.53981633974483
console.log(circumference(10)); //62.83185307179586


let p = document.createElement("p");
p.textContent = area(5); //78.53981633974483
document.body.appendChild(p);

p = document.createElement("p");
p.textContent = circumference(10); //62.83185307179586
document.body.appendChild(p);

