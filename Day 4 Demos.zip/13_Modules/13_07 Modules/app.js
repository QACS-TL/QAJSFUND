//app.js
import * as circle from "./circle-functions.js";
import banana from "./circle-functions.js";


console.log(circle.area(50)); //7853.981633974483
console.log(circle.circumference(100)); //628.3185307179586
console.log(banana); //{radius: 5, area: 7853.981633974483, circumference: 628.3185307179586,  diameter: 10,  centre: [0,0]}


let p = document.createElement("p");
//p.textContent = banana; // prints [object Object]
p.textContent = `radius: ${banana.radius}, area: ${banana.area}, circumference: ${banana.circumference}, diameter: ${banana.diameter}, centre: ${banana.centre}`; // radius: 5, area: 7853.981633974483, circumference: 628.3185307179586,  diameter: 10,  centre: [0,0]
document.body.appendChild(p);

p = document.createElement("p");
p.textContent = circle.area(banana.radius); //78.53981633974483
document.body.appendChild(p);
