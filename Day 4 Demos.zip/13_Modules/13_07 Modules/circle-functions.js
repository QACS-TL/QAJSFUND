//circle-functions.js
export {area, circumference, diameter, radius, radius_from_area}

function area(r) {
  return Math.PI * square(r); // can call square even though it's not been exported because it is local
}

function circumference(r) {
  return 2 * Math.PI * r;
}

function diameter(r) {
  return 2 * r;
}

function radius(d) {
  return d / 2;
}

function radius_from_area(a) {
  return Math.sqrt(a / Math.PI);
}

// Note this function has NOT been exported
function radius_from_circumference(c) {
  return c / (2 * Math.PI);
}

function square(v) {
  return Math.pow(v, 2);
}


// A module can export many helpers (named exports)…
// (e.g., area(), circumference())
// …and also expose one main thing
// (default export — the “primary” object or function)
// This is common in:
// - utility libraries
// - classes or factory functions
// - configuration modules
// - React components (default export for the component)
export default {
  radius: 5,
  area: area(10), // result of function call: 314.1592653589793
  circumference: 628.3185307179586,
  diameter: 10,
  centre: [0,0]
}
