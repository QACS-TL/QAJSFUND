//app.js
import * as circle from "./circle-functions.js";

console.log(circle.area(50)); //7853.981633974483
console.log(circle.circumference(100)); //628.3185307179586


let p = document.createElement("p");
p.textContent = circle.area(50); //7853.981633974483
document.body.appendChild(p);

p = document.createElement("p");
p.textContent = circle.circumference(100); //628.3185307179586
document.body.appendChild(p);

