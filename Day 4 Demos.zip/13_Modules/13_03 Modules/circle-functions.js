//circle-functions.js
export function area(r) {
  return Math.PI * Math.pow(r, 2)
}

export function circumference(r) {
  return 2 * Math.PI * r
}

export function diameter(r) {
  return 2 * r
}

export function radius(d) {
  return d / 2
}

export function radius_from_area(a) {
  return Math.sqrt(a / Math.PI)
}

export function radius_from_circumference(c) {
  return c / (2 * Math.PI)
}