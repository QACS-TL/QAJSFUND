//app.js
import {area} from "./circle-functions.js";

console.log(area(5)); //78.53981633974483

const p = document.createElement("p");
p.textContent = area(10); //314.1592653589793
document.body.appendChild(p);

document.write(area(10)); // Error - cannot write from a module 